import {
  LOADING,
  ALERT_ERROR,
  ALERT_SUCCESS,
  ALERT_CLOSE
} from "../actions/action-type";

const initialState = {
  isAlert: false,
  success: false,
  error: false,
  loading: false
};

const alertReducers = (state = initialState, action) => {
  switch (action.type) {
    case LOADING:
      return {
        ...state,
        loading: true,
        success: false,
        error: false
      };
    case ALERT_ERROR:
      return {
        ...state,
        loading: false,
        success: false,
        isAlert: true,
        error: action.error
      };
    case ALERT_CLOSE:
      return {
        ...state,
        loading: false,
        success: false,
        isAlert: false
      };
    case ALERT_SUCCESS:
      return {
        ...state,
        loading: false,
        error: null,
        isAlert: true,
        success: action.success
      };
    default:
      return state;
  }
};

export default alertReducers;
