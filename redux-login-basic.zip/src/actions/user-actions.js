import { IS_LOGIN, USER_NAME, USER_PASSWORD } from "./action-type";
import { pageLoading, alertError } from "./alert-actions";
export const userName = username => {
  const type = USER_NAME;
  return { type, username };
};
export const userPassword = password => {
  const type = USER_PASSWORD;
  return { type, password };
};
export const userLogin = token => {
  const type = IS_LOGIN;
  return { type, token };
};

export const userLoginSubmit = (username, password) => {
  return dispatch => {
    dispatch(pageLoading());
    console.log(username, typeof username, password, typeof password);
    if (username === "emrah" && password === "1388") {
      dispatch(userLogin(Math.random()));
    }
    return dispatch(alertError("Kullanıcı Adı Şifre Hatalı"));
  };
};
