import React, { Component } from "react";
import { connect } from "react-redux";
class Home extends Component {
  render() {
    console.log("props", this.props);
    return <div>Anasayfa</div>;
  }
}
export default connect()(Home);
