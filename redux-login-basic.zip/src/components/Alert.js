import React, { Component } from "react";
import {
  Dialog,
  Button,
  DialogContentText,
  DialogActions,
  DialogContent
} from "../includes";
import { connect } from "react-redux";
class Alert extends Component {
  state = {
    open: false
  };

  handleClickOpen = () => {
    this.setState({ open: true });
  };

  handleClose = () => {
    this.setState({ open: false });
  };

  render() {
    const { isAlert, error, success } = this.props;
    console.log("alert", this.props);
    return isAlert ? (
      <Dialog
        open={isAlert}
        keepMounted
        onClose={this.handleClose}
        aria-labelledby="alert-dialog-slide-title"
        aria-describedby="alert-dialog-slide-description"
      >
        <DialogContent>
          <DialogContentText id="alert-dialog-slide-description">
            {error && error}
            {success && success}
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={this.handleClose} color="primary">
            Tamam
          </Button>
        </DialogActions>
      </Dialog>
    ) : null;
  }
}
export default connect()(Alert);
